# Feature Lists

Save Video, Liked Video, Video Delete and Channel Delete for Django projects.

## Installation

```bash
pip install feature_lists
